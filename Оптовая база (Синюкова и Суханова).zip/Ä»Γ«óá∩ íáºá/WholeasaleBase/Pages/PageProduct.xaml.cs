﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WholeasaleBase.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace WholeasaleBase.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageProduct.xaml
    /// </summary>
    public partial class PageProduct : Page
    {   

        
        public PageProduct()
        {
            InitializeComponent();
            DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.ToList();

            CmbFiltrProv.ItemsSource = WholesaleDBEntities.GetContext().Provider.ToList();
            CmbFiltrProv.SelectedValuePath = "IdProv";
            CmbFiltrProv.DisplayMemberPath = "Name";


        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {//редактирование
            ClassFrame.frmObj.Navigate(new AddEditPage((sender as Button).DataContext as Product));

        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {//добавление
            ClassFrame.frmObj.Navigate(new AddEditPage(null));

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {//удаление нескольких пользователей
            var productForRemoving = DGridProduct.SelectedItems.Cast<Product>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {productForRemoving.Count()} данный продукт?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    WholesaleDBEntities.GetContext().Product.RemoveRange(productForRemoving);
                    WholesaleDBEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }

        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {//динамическое отображение данных или изменение данных
            if (Visibility == Visibility.Visible)
            {
                WholesaleDBEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.ToList();
            }

        }

        private void CmbFiltrProv_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrProv.SelectedIndex + 1;
            DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.Where(x => x.ProviderFK == id).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.ToList();
        }
        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.Where(x => x.Name.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.OrderBy(x => x.Name).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.OrderByDescending(x => x.Name).ToList();
        }

        private void BtnToList_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new Images());
        }

        private void BtnExcel_Click(object sender, RoutedEventArgs e)
        {

            // объект Excel
            var app = new Excel.Application();

            // книга
            Excel.Workbook wb = app.Workbooks.Add();

            // лист
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 1;
            // ячейки
            // 1 - номер столбца 
            // 2 - номер строки
            worksheet.Cells[1][indexRows] = "Номер";
            worksheet.Cells[2][indexRows] = "Название";
            worksheet.Cells[3][indexRows] = "Количество";
            worksheet.Cells[4][indexRows] = "Единица измерения";
            worksheet.Cells[5][indexRows] = "Стоимость";
            worksheet.Cells[6][indexRows] = "Описание";
            worksheet.Cells[7][indexRows] = "Поставщик";
            var printItems = DGridProduct.Items;
            
            Excel.Range Bold = worksheet.Range[worksheet.Cells[1][indexRows], worksheet.Cells[8][indexRows]];
            Bold.Font.Bold = worksheet.Cells[1][indexRows].Font.Bold = true;
            Excel.Range Borders = worksheet.Range[worksheet.Cells[1][1], worksheet.Cells[7][6]];
            Borders.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle =
            Borders.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;
            Borders.ColumnWidth = 30;

            worksheet.Columns.AutoFit();

            //цикл по данным из таблицы
            foreach (Product item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = indexRows;
                worksheet.Cells[2][indexRows + 1] = item.Name;
                worksheet.Cells[3][indexRows + 1] = item.Amount;
                worksheet.Cells[4][indexRows + 1] = item.Measure;
                worksheet.Cells[5][indexRows + 1] = item.Cost;
                worksheet.Cells[6][indexRows + 1] = item.Note;
                worksheet.Cells[7][indexRows + 1] = item.Provider.Name.ToString();
                indexRows++;    
            }
            Excel.Range sumRange = worksheet.Range[worksheet.Cells[1][indexRows+1], worksheet.Cells[4][indexRows+1]];
            sumRange.Merge();
            Excel.Range sumRange1 = worksheet.Range[worksheet.Cells[5][indexRows + 1], worksheet.Cells[7][indexRows + 1]];
            sumRange1.Merge();
            sumRange.Value = "Общее кол-во товаров:";
            sumRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            worksheet.Cells[5][6].Formula = $"=SUM(C{indexRows}:" + $"C{indexRows-4})";
            //Excel.Range sumRange2 = worksheet.Range[worksheet.Cells[1][indexRows + 2], worksheet.Cells[4][indexRows + 2]];
            //sumRange2.Merge();
            //sumRange2.Value = "Общая стоимость товаров:";
            //sumRange2.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            //worksheet.Cells[5][7].Formula = $"=SUMPRODUCT(C{indexRows}:" + $"C{indexRows - 4}:" + $"E{indexRows}:" + $"E{indexRows-4})";


            // показать Excel
            app.Visible = true;
        }
    }
}
