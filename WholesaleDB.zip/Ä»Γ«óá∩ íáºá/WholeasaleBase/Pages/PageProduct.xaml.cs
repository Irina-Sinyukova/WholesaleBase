﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WholeasaleBase.Classes;

namespace WholeasaleBase.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageProduct.xaml
    /// </summary>
    public partial class PageProduct : Page
    {
        public PageProduct()
        {
            InitializeComponent();
            DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.ToList();

            CmbFiltrProv.ItemsSource = WholesaleDBEntities.GetContext().Provider.ToList();
            CmbFiltrProv.SelectedValuePath = "IdProv";
            CmbFiltrProv.DisplayMemberPath = "Name";
            
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {//редактирование
            ClassFrame.frmObj.Navigate(new AddEditPage((sender as Button).DataContext as Product));

        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {//добавление
            ClassFrame.frmObj.Navigate(new AddEditPage(null));

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {//удаление нескольких пользователей
            var productForRemoving = DGridProduct.SelectedItems.Cast<Product>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {productForRemoving.Count()} данный продукт?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    WholesaleDBEntities.GetContext().Product.RemoveRange(productForRemoving);
                    WholesaleDBEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }

        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {//динамическое отображение данных или изменение данных
            if (Visibility == Visibility.Visible)
            {
                WholesaleDBEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.ToList();
            }

        }

        private void CmbFiltrProv_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrProv.SelectedIndex + 1;
            DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.Where(x => x.ProviderFK == id).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.ToList();
        }
        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.Where(x => x.Name.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.OrderBy(x => x.Name).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridProduct.ItemsSource = WholesaleDBEntities.GetContext().Product.OrderByDescending(x => x.Name).ToList();
        }
    }
}
